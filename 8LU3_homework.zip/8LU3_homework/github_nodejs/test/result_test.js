require.paths.unshift(__dirname + '/../lib');
var sys,
    vows,
    assert,
    result;

sys = require('sys');
vows = require('vows');
assert = require('assert');
result = require('result');

vows.describe('Result').addBatch({
  'List Repos' : {
    topic: function() {
      return result.listRepos;
    },
    
    '': function(listRepos) {
      assert.equal();
    }
  },
  'Request from GitHub' : {
    topic: function() {
      return result.requestFromGitHub;
    },
    'returns request object': function(requestFromGitHub) {
      var request;
      request = requestFromGitHub('sl4m');
      console.log(sys.inspect(request));
      assert.equal();
    }
  },
  'Write Repos' : {
    topic: function() {
      return result.writeRepos;
    },
    '': function(writeRepos) {
      assert.equal();
    }
  }
}).export(module);
