require.paths.unshift(__dirname + '/../lib');
var sys,
    vows,
    assert,
    home,
    req,
    res;

sys = require('sys');
vows = require('vows');
assert = require('assert');
home = require('home');

res = function() {
  var _status,
      _attributes,
      _html;
  return {
    getStatus: function() {
      return _status;
    },
    getAttributes: function() {
      return _attributes;
    },
    getHTML: function() {
      return _html;
    },
    writeHead: function(status, attributes) {
      _status = status;
      _attributes = attributes;
    },
    write: function(html) {
      _html = html;
    },
    end: function() {
      return true;
    }
  };
}();

vows.describe('Search User').addBatch({
  'Page' : {
    topic: function() {
      return home.searchUser;
    },

    'writes 200 to header': function(searchUser) {
      searchUser(req, res);
      assert.equal(res.getStatus(), 200);
    },
    'uses text/html Content-Type': function(searchUser) {
      searchUser(req, res);
      assert.equal(res.getAttributes()['Content-Type'], 'text/html');
    },
    'creates input text field with github_user id' : function(searchUser) {
      searchUser(req, res);
      assert.match(res.getHTML(), /input type="text" name="github_user"/);
    },
    'create submit button' : function(searchUser) {
      searchUser(req, res);
      assert.match(res.getHTML(), /input type="submit" value="Search"/);
    }
  }
}).export(module);
