# Instructions

You'll need to create a file named .creds in the same directory as this README,
and the contents should be a single line with your Twitter username and
password, separated by a `:` (extra spaces or lines will probably blow up the
app):

`TWITTER_USERNAME_HERE:TWITTER_PASSWORD_HERE`

Then, in the same directory, just run:

`node twitter_mini.js`
