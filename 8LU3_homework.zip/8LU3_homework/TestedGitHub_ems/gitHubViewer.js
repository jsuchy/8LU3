exports.gitHub = function() {};

exports.gitHub.prototype = {
  getFollowers: function(httpClient)
  {
    var request = httpClient.createClient(80, "www.github.com");
    request.request('GET', '/api/v2/json/repos/watched/' + this.username, {'host': 'github.com'});
    request.end();
  }
}
