var http = require('http');

http.createServer(function (req, res) {
  if(req.url === "/favicon.ico")
    return;

  var query = require('url').parse(req.url, true).query;

  if(typeof(query) !== 'undefined' && query != null) {
    res.writeHead(200, {'Content-Type': 'text/plain'});

    console.log("make the request to github");

    var gitHub = http.createClient(80, 'github.com');
    var request = gitHub.request('GET', "/api/v2/json/repos/watched/" + query.username, {'host': 'github.com'});
    request.end();

    request.on('response', function (response) {
      var body = "";
      response.setEncoding('utf8');
      response.on('data', function (chunk) {
        body += chunk;
      });

      response.on('end', function () {
        var theJSON = JSON.parse(body);
        res.write(query.username + " watches " + theJSON.repositories.length + " repositories\n");
        theJSON.repositories.forEach(function(repository) {
          res.write("Name: " + repository.name + " Owner: " + repository.owner + "\n");
          });
        res.end("\nThe End");
      });
    });
  }

}).listen(8124, "127.0.0.1");

console.log('Server running at http://127.0.0.1:8124/')
