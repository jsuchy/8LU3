var assert = require('assert'),
    requestMockery = require('./request_mockery');

exports.mockHttp = function() {};

exports.mockHttp.prototype = {
  createClient: function(port, url)
  {
    this.port = port;
    this.url = url;
    this.requestCall = new(requestMockery.mockRequest);
    return this.requestCall;
  },

  assertCreatedClientWith: function(port, url)
  {
    assert.ok(this.port === port);
    assert.ok(this.url === url);
  }
}
