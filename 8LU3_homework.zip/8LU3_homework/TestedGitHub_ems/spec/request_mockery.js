var assert = require('assert');

exports.mockRequest = function() {};

exports.mockRequest.prototype = {
  request: function(type, url, options)
  {
    this.type = type;
    this.url = url;
    this.options = options;
  },

  end: function()
  {
    if (this.type != null)
    {
      this.validEndCalled = true;
    }
  },

  on: function(type, request_callback)
  {
    if (type === "data")
    {
      request_callback("{repositories[{name: 'mine', owner: 'me'}]");
    }

    if (type == "end")
    {
      request_callback();
    }
  },

  assertCalledWith: function(type, url, host)
  {
    assert.ok(this.type === type);
    assert.ok(this.url === url);
    assert.ok(this.options.host === host);
  },

  assertCalledEnd: function()
  {
    assert.ok(this.validEndCalled);
  }
}
