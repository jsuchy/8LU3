var vows = require ('vows'),
	assert = require ('assert'),
  gitHubViewer = require('../gitHubViewer'),
  httpMockery = require('./http_mockery');

/* Extending assert */
assert.notNull = function notNull(expected)
{
  assert.notEqual(expected, null);
}

vows.describe ('Git Hub Viewer').addBatch({
	'Git Hub': {
		'show watched': {
      topic: new(gitHubViewer.gitHub),

			'testExists': function (git) {
        assert.notNull(git);
			},

      'testCreatesGitHubClient': function(git) {
        var mockttp = new(httpMockery.mockHttp);
        git.getFollowers(mockttp);

        mockttp.assertCreatedClientWith(80, 'www.github.com');
      },

      'testMakesTheRightRequest': function(git) {
        var mockttp = new(httpMockery.mockHttp);
        git.username = "monkey";
        git.getFollowers(mockttp);

        var request = mockttp.requestCall;

        request.assertCalledWith('GET', "/api/v2/json/repos/watched/monkey", "github.com");
      },

      'testEndsTheRequestAfterMakingIt' : function(git) {
        var mockttp = new(httpMockery.mockHttp);
        git.getFollowers(mockttp);

        var request = mockttp.requestCall;

        request.assertCalledEnd();
      },

      'testWritesNameAndOwnerToResponse' : function(git) {
        var mockttp = new(httpMockery.mockHttp);
        var responseData;

        git.responseCallback = function(data) {
          responseData = data;
        }

        git.getFollowers(mockhttp);
      }
		}
	}
}).export(module);
