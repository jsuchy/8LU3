var fs = require('fs')
var http = require('http');
var downloader = require ('./downloader')
var Downloader = downloader.Downloader;

http.createServer(function (request, response) {
	var parsed_url = require('url').parse(request.url, true);

	var myDownloader = new Downloader;
	if (myDownloader.isDownloadLink(parsed_url.pathname)) {
		var path = myDownloader.path(parsed_url.query.filename);
		fs.readFile(path, "binary", function (err, data) {
		  if (err) throw err;
		  response.writeHead(200, myDownloader.headers);
      response.write(data, "binary");  
      response.end()
		});
		
	} else {
		response.writeHead(200, {'Content-Type': 'text/html'});
	  response.end('<a href="/">Home</a><br/><a href="download?filename=test1">File 1</a><br/><a href="download?filename=test2">File 2</a>');
	}


}).listen(8124);

console.log('Server running at http://127.0.0.1:8124/');