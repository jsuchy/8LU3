var fs = require('fs');
exports.Downloader = function () {}

exports.Downloader.prototype = {
	headers: {'Content-Type': 'application/txt', 'Content-Disposition': 'attachment'},
	
	isDownloadLink: function (pathname) {
		return pathname === "/download";
	},
	
	path: function (filename) {
		return "files/" + filename;
	}
};