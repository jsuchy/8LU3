var vows = require ('vows'),
	assert = require ('assert');
var downloader = require ('./downloader')
var Downloader = downloader.Downloader;
	
vows.describe ('Downloader').addBatch({
	'Downloader': {
		'Downloader': {
			topic: new (Downloader),
			
			'testIsDownloadLinkReturnsTrue': function (downloader) {
				assert.isTrue(downloader.isDownloadLink("/download"));
			},

			'testIsDownloadLinkReturnsFalse': function (downloader) {
				assert.isFalse(downloader.isDownloadLink("/not_download"));
			},

			'testHeaders': function (downloader) {
				assert.deepEqual(downloader.headers, {'Content-Type': 'application/txt', 'Content-Disposition': 'attachment'})
			},
			
			'testFilepath': function (downloader) {
				assert.equal(downloader.path("my_file"), "files/my_file");
			}
		}
	}
}).export(module);
