var assert = require('assert');
var chat   = require('./chat');
var fs     = require('fs');
var html   = require('./html');
var http   = require('http');
var sys    = require('sys');
var vows   = require('vows');

var headers = {'content-type': 'text/html'};

var request = function() {
}

var response = function() {
	this.code = "";
	this.headers = "";
	this.body = "";
};

response.writeHead = function(code, headers) {
	this.code = code;
	this.headers = headers;
};

response.write = function(body) {
	this.body += body;
};

response.end = function(body) {
	this.body += body;
};

vows.describe('Chat').addBatch({
	'should append to log': function(log, id, message) {
		assert.equal(chat.appendLog("", "naush", "liar"), "naush: liar <br />\n");
	},
	'should write response headers': function() {
		chat.writeResponse(response, 200, headers, "test");
		assert.equal(response.code, '200');
		assert.equal(response.headers, headers);
	},
	'should update log': function() {
		// chat.update(response, "naush", "liar", "test.txt");
		// assert.equal(response.code, '200');
		// assert.equal(response.headers, headers);
		// sys.debug(response.body);
	},
	'should refresh page': function() {
		// chat.refresh(response, "test.txt");
	},
	'should deploy': function() {
		// chat.deploy(8000);
		// chat.server.close();
	},
	'should serve db': function() {
		request.method = '/test.txt';
		chat.serve(request, response);
		assert.equal(response.code, '200');
		assert.equal(response.headers, headers);
	}
}).run();
