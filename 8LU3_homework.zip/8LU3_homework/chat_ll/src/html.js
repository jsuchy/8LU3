var formidable = require('formidable');

exports.header = '<head>'
			   // + '<script type="text/javascript" src="jquery.js"></script>'
			   // + '<script type="text/javascript" src="reload.js"></script>'
			   + '<script>function refresh() {window.location.reload();}</script>'
			   + '</head>\n';
exports.form   = new formidable.IncomingForm();
exports.db     = "message.txt";
exports.log    = "";
exports.inputForm = function(id) {
	return '<form action="/" method="post">'
    + '<input type="text" name="id" size="10" value="' + id + '">'
    + '<input type="text" name="message" size="30" value="">'
    + '<input type="submit" value="Enter">'
    + '</form>';
}
exports.wrapper = function(content) {
	return '<body onLoad="setInterval(\'refresh()\', 10000);"><div id="room">' + content + '</div></body>';
}
