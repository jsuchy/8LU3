var http       = require('http');
var sys        = require('sys');
var fs         = require('fs');
var html	   = require('./html');

var log		   = "";

exports.deploy = function(port) {
	exports.server.listen(port);
}

exports.serve = function(request, response) {
  if (request.method === 'POST') {
    html.form.parse(request, function(err, fields, files) {
      // exports.update(response, fields.id, fields.message, html.db);
    });
    return;
  } else if (request.url === '/' + html.db) {
	response.writeHead(200, {'content-type': 'text/html'});
	fs.readFile(html.db, function(err, data) {
		if (err) throw err;
		response.end(data);
	});
  } else {
	exports.refresh(response, html.db);
  }
}

exports.server = http.createServer(exports.serve);

exports.writeResponse = function(response, code, headers, body) {
  response.writeHead(code, headers);
  response.end(html.header + html.wrapper(body));
}

exports.writeFile = function(log) {
  fs.writeFile(html.db, log, function (err) {
    if (err) throw err;
  });
}

exports.update = function(response, id, message, db) {
  fs.readFile(db, function (err, data) {
    if (err) throw err;
    log = exports.appendLog(data, id, message);
	exports.writeFile(log);
	exports.writeResponse(response, 200, {'content-type': 'text/html'}, log + html.inputForm(id));
  });
}

exports.refresh = function(response, db) {
  fs.readFile(db, function (err, data) {
    if (err) throw err;
	exports.writeResponse(response, 200, {'content-type': 'text/html'}, data + html.inputForm(''))
  });
}

exports.appendLog = function(data, id, message) {
	return data + id + ': ' + message + ' <br />\n';
}
