var chat = require('./chat');
chat.deploy(8000);
