// based on http://debuggable.com/posts/streaming-file-uploads-with-node-js:4ac094b2-b6c8-4a7f-bd07-28accbdd56cb

var   sys = require("sys"),
       fs = require('fs'),
      url = require('url'),
     http = require("http");

var counter, last_hit_by, goal;
counter = 0;
goal = 5;
last_hit_by = "";

var updater = {
	home: function(request,data, response) {
	  response.writeHead(200, {'Content-Type': 'text/html'});
	  res = 
			'<html><head><title>node.js HTTP server example</title>'+
			'<meta http-equiv="refresh" content="5;url=/"/></head>' +
			'<h2> Who\'s Up Next? </h2>'+
			'<h4> The Game that tests your impatience </h4>' +
	    '<form action="/up" method="POST">' +
			'<label for="user_name"> Your Name: </label>' +
	    '<input type="text" id="user_name" name="user_name" value="'+data+'">' +
	    '<input type="submit" value="Lets UP it!">' +
	    '</form>'+
			'<h3> Count is at: ' + counter + ' </h3>';
		if (data.length > 0)
			last_hit_by = data;
		if(last_hit_by.length > 0)
			res += '<h4> Last Hit by: ' + last_hit_by + '</h4>';
		res += 'Next Goal: ' + goal;
		if (goal === counter){
			goal = goal * 2;
			res += '<h2> ' + last_hit_by + ' HIT THE GOAL!! </h2>';
		}
		response.write(res);
	  response.end();
	},

	up: function(request,data, response) {
		var user_name = data.split(/=/)[1];
	  counter += 1;
		this.home(request, user_name,response);
		return data;
	},

	show_404: function(request, response) {
	  response.writeHead(404, {'Content-Type': 'text/plain'});
	  response.write('404 - Please try again.');
	  response.end();
	}
};

http.createServer(function (request, response) {
  switch (url.parse(request.url).pathname) {
    case '/':
      updater.home(request, "",response);
      break;
    case '/up':
			var chunks = "";
			request.on("data", function(chunk) {
				chunks += chunk;
			});
			request.on("end", function() {
				updater.up(request,chunks, response);
			});
      break;
    default:
      updater.show_404(request, response);
      break;
  }
}).listen(8000);